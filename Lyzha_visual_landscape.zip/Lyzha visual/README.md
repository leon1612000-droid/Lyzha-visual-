# Lyzha visual

Android gaming launcher prototype.

## Stage 1
- App name: Lyzha visual
- Custom launcher icon
- Startup visual intro video (`visual_intro.mp4`)
- After the intro, the basic launcher screen is shown

Next stage: detect installed games, show game cards, and add launch buttons.
