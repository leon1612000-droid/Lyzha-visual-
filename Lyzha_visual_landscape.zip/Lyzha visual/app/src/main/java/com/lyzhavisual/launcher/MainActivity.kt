package com.lyzhavisual.launcher

import android.app.Activity
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import android.widget.VideoView

class MainActivity : Activity() {

    private var backgroundVideo: VideoView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showIntro()
    }

    private fun showIntro() {
        val intro = VideoView(this).apply {
            setBackgroundColor(Color.WHITE)
            setVideoURI(Uri.parse("android.resource://$packageName/${R.raw.visual_intro}"))
            setOnPreparedListener { it.isLooping = false; start() }
            setOnCompletionListener { showWelcomeMenu() }
            setOnErrorListener { _, _, _ -> showWelcomeMenu(); true }
        }
        setContentView(intro)
        intro.start()
    }

    private fun showWelcomeMenu() {
        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)

        val video = VideoView(this).apply {
            setVideoURI(Uri.parse("android.resource://$packageName/${R.raw.menu_background}"))
            setOnPreparedListener { player ->
                player.isLooping = true
                player.setVolume(0f, 0f)
                start()
            }
        }
        backgroundVideo = video
        root.addView(video, FrameLayout.LayoutParams(-1, -1))

        val shade = View(this).apply {
            setBackgroundColor(Color.argb(85, 0, 0, 0))
        }
        root.addView(shade, FrameLayout.LayoutParams(-1, -1))

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(32, 80, 32, 44)
        }

        val spacerTop = View(this)
        content.addView(spacerTop, LinearLayout.LayoutParams(1, 0, 1f))

        val welcome = TextView(this).apply {
            text = "Добро пожаловать"
            textSize = 32f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setShadowLayer(10f, 0f, 3f, Color.BLACK)
        }
        content.addView(welcome, LinearLayout.LayoutParams(-1, -2))

        val name = TextView(this).apply {
            text = "Визуалы Лужи"
            textSize = 24f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 0)
            setShadowLayer(8f, 0f, 2f, Color.BLACK)
        }
        content.addView(name, LinearLayout.LayoutParams(-1, -2))

        val spacerMiddle = View(this)
        content.addView(spacerMiddle, LinearLayout.LayoutParams(1, 0, 1f))

        val enter = Button(this).apply {
            text = "ЗАЙТИ"
            textSize = 18f
            setTextColor(Color.WHITE)
            setOnClickListener { showAuthMenu() }
            background = getDrawable(android.R.drawable.btn_default)
        }
        val buttonParams = LinearLayout.LayoutParams(-1, 58).apply {
            leftMargin = 24
            rightMargin = 24
            bottomMargin = 8
        }
        content.addView(enter, buttonParams)

        root.addView(content, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)
        video.start()
    }

    private fun showAuthMenu() {
        backgroundVideo?.stopPlayback()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(40, 40, 40, 40)
            setBackgroundColor(Color.rgb(8, 0, 13))
        }

        val title = TextView(this).apply {
            text = "Вход"
            textSize = 30f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        root.addView(title, LinearLayout.LayoutParams(-1, -2))

        val subtitle = TextView(this).apply {
            text = "Выберите способ авторизации"
            textSize = 16f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 28)
        }
        root.addView(subtitle, LinearLayout.LayoutParams(-1, -2))

        val google = Button(this).apply {
            text = "Войти через Google"
            setOnClickListener {
                Toast.makeText(this@MainActivity, "Google OAuth подключим после добавления Client ID", Toast.LENGTH_LONG).show()
            }
        }
        root.addView(google, LinearLayout.LayoutParams(-1, 58).apply { bottomMargin = 16 })

        val vk = Button(this).apply {
            text = "Войти через VK"
            setOnClickListener {
                Toast.makeText(this@MainActivity, "VK OAuth подключим после добавления ID приложения", Toast.LENGTH_LONG).show()
            }
        }
        root.addView(vk, LinearLayout.LayoutParams(-1, 58))

        val back = Button(this).apply {
            text = "Назад"
            setOnClickListener { showWelcomeMenu() }
        }
        root.addView(back, LinearLayout.LayoutParams(-1, 54).apply { topMargin = 28 })

        setContentView(root)
    }

    override fun onDestroy() {
        backgroundVideo?.stopPlayback()
        super.onDestroy()
    }
}
